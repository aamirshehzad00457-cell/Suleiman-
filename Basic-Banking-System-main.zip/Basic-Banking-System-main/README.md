# the-sparks-foundation
Sparks Foundation Internship Project :Basic Banking System
A Web application used to transfer money between multiple users (Project contains 10 dummy users). A dummy user can also  be created.

Stack used -
Front-end : HTML, CSS ,Bootstrap & Javascript
Back-end  : PHP
Database  : MySQL

Database contains two Tables- Users Table & Transaction Table
1. User table have basic fields such as name, email & current balance.
2. Transcation table records all transfers happend along with their time.

Flow of the website: Home Page > View all Users > Selected and View one user >Transfer Money > Select receiver >View all users >View.
